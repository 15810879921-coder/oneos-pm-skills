# 云效CLI分配任务适配器

## 1. 唯一执行通道

`分配任务`中的全部云效读取和写入必须通过官方`aliyun devops` CLI执行。禁止使用浏览器、DOM、Cookie、网页内部接口或手工点选作为回退。

本机Git和代码仓库不属于该口令范围；`分配任务`不修改代码。

## 2. 环境门禁

先执行：

```text
skill-run yunxiao_cli_allocate_task.py doctor
```

必须同时满足：

- `aliyun` CLI可执行；
- `aliyun devops version`成功；
- PAT只通过`ALIBABA_CLOUD_YUNXIAO_ACCESS_TOKEN`提供；
- 中心版组织ID只通过`ALIBABA_CLOUD_YUNXIAO_ORGANIZATION_ID`提供；
- 当前PAT用户可回读。

不得把PAT写入参数、Skill、回执、日志、Git或聊天。任一门禁失败时零云效写入并明确阻塞。

## 3. 只读预检

把口令转换为：

```text
skill-run yunxiao_cli_allocate_task.py preflight \
  --task ONEOS-456 \
  --owner 李振 \
  --plan-start 2026-08-03 \
  --plan-finish 2026-08-05 \
  --technical-plan-file <方案.md> \
  --estimated-hours 8
```

存在多条有效开发子任务时增加：

```text
--development-task ONEOS-789
```

预检前先执行`skill-run yunxiao_cli_allocate_task.py analyze --task ...`读取正式关联需求的完整描述，由Agent按`allocation-technical-plan.md`生成方案文件；预检命令必须增加`--technical-plan-file <方案.md>`。预检必须通过CLI完成并输出带哈希的系统临时目录回执：

1. 根据任务编号前缀唯一解析项目，并按精确编号读取`【交付】`。
2. 验证交付负责人=何斐、状态属于`待处理|已分配|处理中`且未关闭。
3. 通过`ASSOCIATED`唯一读取状态为`待开发`的产品需求。
4. 通过`SUB`读取有效`【开发】`子任务，决定创建或复用；不按标题模糊查重。
5. 解析负责人时必须使用成员返回的`userId`，不得误用成员关系记录`id`。
6. 读取并冻结交付任务`priority`的标识ID；缺失时创建路径必须零写入阻塞。
7. 动态读取任务字段配置，唯一解析计划开始、计划完成和预计工时字段ID。
8. 动态读取任务工作流，唯一解析`待处理`和`已分配`状态ID。
9. 校验日期和正数工时，校验技术方案绑定关联需求编号且含实现范围、处理逻辑、实施步骤、验证标准；冻结需求描述哈希、方案哈希、对象、关系、优先级、字段、状态和负责人指纹。

CLI创建工作项要求`assignedTo`。因此：复用任务时负责人无法唯一解析可保留原负责人并报告；创建任务时负责人无法唯一解析必须在预检阶段阻塞，不得临时指派其他人。

## 4. 按回执执行

预检通过后执行：

```text
skill-run yunxiao_cli_allocate_task.py apply --preflight <预检回执路径>
```

执行器必须先重新预检。工作项、关系、负责人解析、字段配置或状态配置任一变化时拒绝写入并要求重新预检。

未漂移时按固定顺序执行：

1. 创建或复用唯一`【开发】<需求标题>`；创建时使用`parent-id`直接归入来源交付，并把交付任务`priority`标识ID原样写入开发任务。复用已有开发任务时保留其现有优先级，不做覆盖。
2. 写负责人、计划开始`00:00:00`、计划完成`23:59:59`并保持任务=`待处理`；可选预计工时必须通过官方CLI的`projex-create-estimated-effort`/`projex-update-estimated-effort`专用接口登记，并用`projex-list-estimated-efforts`按合计值回读，不得把预计工时当作通用自定义字段更新。
3. 幂等维护描述中的`## 技术实施方案`，删除旧的本Skill生成的`## 下一阶段`命令块，保留区块外人工内容。
4. 通过CLI创建或复用`PARENT→交付`和`ASSOCIATED→需求`，逐条回读。
5. 聚合回读开发任务负责人、优先级、日期、工时、状态、两条关系和技术方案哈希；新建任务的优先级标识ID必须与交付任务完全一致。
6. 全部通过后，交付为`待处理`时更新到`已分配`；已为`已分配|处理中`时幂等保持；需求保持`待开发`。
7. 输出带哈希执行回执和实际操作清单。

任何中间步骤失败时不得删除已创建任务、补造关系或切换到网页继续。报告已经完成的CLI动作、未执行动作和重试条件；重试先重新预检，按真实状态幂等继续。

## 5. 回报

至少包含：

```text
CLI/插件/凭证变量：
预检回执/哈希：
项目/需求/交付/开发任务：
创建或复用：
负责人/优先级/计划开始/计划完成/预计工时：
正式关系：PARENT→交付；ASSOCIATED→需求
状态变化：
实际执行操作：
实际代码变更：无（仅进行云效任务分配）
未执行操作及原因：
下一条口令：
```
