# 测试执行与发布候选交接

测试任务编号与测试周期由测试链路正常产生，不得用临时开发编号替代。Bug 是否进入既有开发分支，只看其唯一开发任务归属；没有开发任务时允许先测试、先建 Bug，并由开发侧走独立 Bug 分支。开发任务后置不会改变既有测试执行ID、Bug复测ID或已取得证据。

## 状态所有权

```text
开始测试：
【测试】待处理 → 处理中
首个正式测试范围：需求开发中/开发完成/待测试 → 测试中

完成测试：
【测试】处理中 → 已完成
仅全部承诺范围聚合闭环时：需求测试中 → 测试完成
```

任何一侧状态或正式关系不符时零写入。不得用“测试任务已完成”推断需求已自动进入测试完成；必须回读需求真实状态。

## 交付端分流（Web / 小程序）

接收测试任务不依赖部署区块；实际执行前核对待测版本与环境。当前普通记录/完成执行器读取`oneos.test-deployment/v1`，按其`deliveryEnd`分流：

| 交付端 | test 部署证据 | QA 侧要求 |
| --- | --- | --- |
| `Web`（`PC`视为`Web`） | 环境=`test`、终态成功、含执行ID与部署版本 | 原门禁不变 |
| `小程序` | `deliveryEnd=小程序`、`testPipeline=skipped`、`status=skipped`、含`reason` | 跳过test流水线与自动化测试证据；仍要求测试计划、用例执行、报告和逐Bug复测证据 |

小程序端说明：

- 小程序无法执行云效test流水线与自动化测试，缺流水线属预期，不算证据缺失，也不得伪造执行ID、部署版本或流水线URL。
- 小程序的用例执行由测试人员在小程序测试版本上手工完成；`caseRun`计数与TestHub回读门禁不放宽。
- 复测版本用小程序测试版本标识（如体验版版本号），由开发或测试提供；不得留空。
- 只有`deliveryEnd=小程序`可跳过；其他端写`testPipeline=skipped`一律阻塞。

## 开始测试

```text
$YunxiaoQA
开始测试：测试任务=ONEOS-xx；[需求=ONEOS-yy]
```

执行：

1. 按编号精确读取【测试】，验证唯一父【交付】和正式关联需求；回读 `oneos.test-scope/v1`，确认需求、交付、开发任务和范围。产品交接包、资料哈希、迭代、部署区块不作为接收门禁；产品资料缺口与环境准备另行说明，不生成通过结论。
2. 口令给需求时必须与正式关系一致；未给时从正式关系唯一反查。
3. 验证【测试】=`待处理`；需求可为`开发中`、`开发完成`、`待测试`或`测试中`。首个正式范围不等待兄弟开发任务。
4. 先预检，再在同一已确认 Plan 中加`--apply`执行：

```powershell
skill-run yunxiao_cli_test_lifecycle.py start `
  --space-id <项目ID> `
  --test-sn ONEOS-xx `
  --req-sn ONEOS-yy `
  --idempotency-key 'qa-start-ONEOS-xx'
```

5. 写入前重新校验任务、需求状态、正式关系和范围未变化；仅推进【测试】到`处理中`、需求到`测试中`并官方回读，保留描述。任一失败时报告部分状态。该操作是接收任务，不产生验收通过证据。

## 测试证据

## 证据分段与继续边界

TestHub、测试报告、复测记录或测试环境暂时不可读时，不得把“暂时拿不到证据”写成测试失败，也不得代替开发或产品修复云效关系。按以下边界处理：

- 可继续：开始测试后，测试执行、缺陷创建、缺陷复现记录和已取得的测试证据可以继续；测试任务保持`处理中`、需求保持`测试中`。
- 仅完成测试待补：计划、用例执行、报告、待测版本、逐Bug复测或暂不修复批准任一证据无法核验时，记录`测试证据待补`及最小补齐方式，不推进【测试】或需求到完成态。
- 硬阻塞：测试任务/需求/项目不唯一、测试任务与需求的正式关系冲突、写入对象不明确、权限不足或证据与另一项目/版本明确冲突时，停止对应写入。

测试部署缺失或版本无法确认时，可以接收任务并准备测试，但应报告`待测版本/环境待确认`；实际用例执行须先确认版本，不能在未知版本上宣称测试通过。任何缺口都不得伪造TestHub结果、报告URL或复测通过结论。

测试任务描述维护一个机器可解析的`oneos.qa-evidence/v1`幂等区块。证据来源必须是一份由真实测试执行资产导出的JSON清单，不接受聊天中逐项填写的字符串作为完成依据。该区块仅按以下隐藏 HTML 注释格式由脚本写入，不能以`<pre>`、HTML标题或可见JSON污染测试任务正文。计划与范围规则见[test-scope-aggregation.md](test-scope-aggregation.md)：计划属于需求，清单必须说明当前交付端与被选中的范围；不得把整份计划的总进度当成单端结论。

```markdown
<!-- YUNXIAOQA_TEST_EVIDENCE_START -->
<!-- {"schemaVersion":"oneos.qa-evidence/v1","sourceVerified":true,"projectId":"...","iterationId":"...","iterationName":"...","requirementId":"...","testTaskId":"...","testPlan":{"id":"...","url":"..."},"caseRun":{"id":"...","url":"...","status":"completed","total":10,"passed":10,"failed":0,"blocked":0,"unexecuted":0},"caseCounts":{"total":10,"passed":10,"failed":0,"blocked":0,"unexecuted":0},"report":{"id":"...","url":"..."},"testDeployment":{"executionId":"...","deployedVersion":"...","evidenceUrl":"..."},"bugSnapshot":[],"bugSnapshotSha256":"...","riskApprovals":{},"manifestSha256":"...","idempotencyKey":"qa-..."} -->
<!-- YUNXIAOQA_TEST_EVIDENCE_END -->
```

小程序端清单的`testDeployment`改写跳过口径，其余字段不变：

```json
"testDeployment":{"deliveryEnd":"小程序","testPipeline":"skipped","testedVersion":"<小程序测试版本>"}
```

只允许替换该受管区块，保留人工描述。计划、用例集合、执行和报告任一为空不得完成测试。

计划用例执行必须先走[TestHub CLI适配](yunxiao-cli-testhub.md)。不能对尚未规划进计划的用例直接标PASS；适配器必须先规划、由官方CLI回读，再更新结果并回读计划进度。

测试进行中可先独立记录并回读证据，不推进状态：

```powershell
skill-run yunxiao_cli_test_lifecycle.py record `
  --space-id <项目ID> `
  --test-sn ONEOS-xx `
  --req-sn ONEOS-yy `
  --handoff-bundle '.\evidence\ONEOS-xx.handoff.json' `
  --evidence-manifest '.\evidence\ONEOS-xx.qa.json' `
  --idempotency-key 'qa-ONEOS-xx-<版本>'
```

预检成功后加`--apply`只写受管证据区块。此时允许活动缺陷；它们会在`complete`阶段阻塞完成。

## 完成测试

```text
$YunxiaoQA
完成测试：测试任务=ONEOS-xx；需求=ONEOS-yy；证据清单=.\evidence\ONEOS-xx.qa.json；暂不修复批准=BUG-ID=批准人|证据
```

脚本入口：

```powershell
skill-run yunxiao_cli_test_lifecycle.py complete `
  --space-id <项目ID> `
  --test-sn ONEOS-xx `
  --req-sn ONEOS-yy `
  --handoff-bundle '.\evidence\ONEOS-xx.handoff.json' `
  --evidence-manifest '.\evidence\ONEOS-xx.qa.json' `
  --risk-approval 'ONEOS-901=王冕|APPROVAL-ID-or-URL' `
  --idempotency-key 'qa-ONEOS-xx-<版本>'
```

预检成功后加`--apply`。脚本必须满足：

- 重新从云效需求/交付/开发/测试任务回读当前 `oneos.handoff-evidence/v1`，按 `qa-complete` 验证：合同哈希与开测时一致、交付版本一致、两个角色回执覆盖全部必需文档/验收项、无阻断 QA 的 `PENDING`，且 `qaResult.formal=true`、每个必需验收项精确一条 `PASS` 证据。
- 【测试】=`处理中`、需求=`测试中`。
- 测试任务含开发侧写入并回读的`oneos.test-deployment/v1`；**Web**要求环境=`test`且部署成功，版本、项目、迭代、需求和测试任务一致；**小程序**要求`deliveryEnd=小程序`、`testPipeline=skipped`、`status=skipped`且含`reason`，项目、迭代、需求、测试任务一致。
- 用例未执行/失败/阻塞均为0。
- 每条已关闭Bug有自己的`oneos.bug-retest/v1`复测通过证据；其他缺陷仅允许有批准证据的`暂不修复`。
- 完成时由脚本从测试任务正式关系实时生成完整`bugSnapshot`及SHA-256；发布侧必须重新读取全部关联Bug并与该快照一致，不能用手填活动Bug数量代替。
- 证据与本项目、迭代、需求、测试任务一致。
- TestHub计划概览必须是`/testhub/plan/<计划ID>/dashboard`，作为同一计划的正式汇总报告；脚本回读当前 `directoryIds` 与 `selectedCaseIds` 对应的全部用例结果和目标执行ID，比较当前范围计数；其他端未执行不阻塞本范围，当前范围缺项、结果歧义、未知状态或失败仍阻塞完成。禁止只信URL。

默认完成后只回读当前【测试】=`已完成`、需求保持`测试中`。仅最后一个范围在预检证明确无未完成关联开发/测试范围时加`--aggregate-complete`，才回读需求=`测试完成`。

## 完成测试（人工确认分支）

当测试人员明确决定人工放行时，仍使用“完成测试”口令，不能把普通“测完了”自动解释成特批：

```text
$YunxiaoQA
完成测试：测试任务=ONEOS-xx；需求=ONEOS-yy；人工确认通过=是；[说明=测试人员确认通过]
```

该完整命令本身就是本次写入授权，不再要求第二次确认。这是行政状态整理路径，不强迫用户伪造正式 QA bundle；无 bundle 仍只能记为 `formal:false`。内部执行：

```powershell
skill-run yunxiao_cli_test_lifecycle.py manual-complete `
  --space-id <项目ID> `
  --test-sn ONEOS-xx `
  --req-sn ONEOS-yy `
  --reason '测试人员确认通过' `
  --idempotency-key 'qa-manual-complete-ONEOS-xx' `
  --apply
```

这条路径可跳过test部署、TestHub测试计划/用例结果、QA manifest、正式交棒 bundle 和未关闭缺陷业务门禁，但不能跳过需求范围聚合。仍必须满足：项目与编号唯一、测试任务正式`PARENT/ASSOCIATED`关系正确、每个非取消开发任务唯一映射测试任务、兄弟测试任务均已完成、状态在允许边界内、确认人可由当前PAT用户回读、关联缺陷快照已记录，写入后两侧状态和`oneos.qa-manual-complete/v1`审计区块可回读。脚本不关闭、不改状态也不删除任何Bug，不把人工确认伪造成普通QA证据；该结果标记为 `formal:false`，下游发布必须拒绝。

## 发布候选交接

```text
来源Skill：YunxiaoQA
目标Skill：yunxiao-release-operations
项目名称/ID：
迭代名称/ID：
需求编号/状态：<REQ-ID>/测试完成
交付任务：
测试任务/状态：<TEST-ID>/已完成
测试计划/用例/执行/报告：
交付端：Web|小程序
测试流水线执行ID：（小程序写 skipped）
缺陷：已关闭=<IDs>；暂不修复及批准=<ID:证据>
完成时间：
幂等键：
允许的下一动作：组建发布批次
建议下一口令：
$yunxiao-release-operations
组建发布批次：迭代=<名称>；需求=<REQ-ID,...>
```

接收方必须重读真实状态与正式关系，不得只相信交接文字。
