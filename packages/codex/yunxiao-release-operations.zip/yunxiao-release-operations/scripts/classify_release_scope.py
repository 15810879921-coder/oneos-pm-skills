#!/usr/bin/env python
"""离线分类发布范围为A/B/C/D；不连接或修改云效。"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import handoff_gate as hg


DEPLOY_SCHEMA = "oneos.test-deployment/v1"
QA_SCHEMA = "oneos.qa-evidence/v1"
BUG_RETEST_SCHEMA = "oneos.bug-retest/v1"


def load_json(path: str) -> dict[str, Any]:
    text = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("输入根节点必须是JSON对象")
    return data


def as_count(item: dict[str, Any], key: str) -> int:
    value = item.get(key, 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{item.get('id')}.{key}必须是非负整数")
    return value


def valid_ref(value: object) -> bool:
    text = str(value or "").strip()
    return bool(text) and text.lower() not in {"none", "null", "n/a", "无", "..."} and not (
        "<" in text or ">" in text
    )


def structured_evidence_gaps(item: dict[str, Any]) -> list[str]:
    """校验证据内容，禁止用调用方自报布尔值代替真实证据。"""
    gaps: list[str] = []
    requirement_id = str(item.get("id") or "")
    project_id = str(item.get("projectId") or "")
    iteration_id = str(item.get("iterationId") or "")
    test_task_id = str(item.get("testTaskId") or "")

    deployment = item.get("testDeployment")
    if not isinstance(deployment, dict):
        return ["缺少结构化test部署证据"]
    if deployment.get("schemaVersion") != DEPLOY_SCHEMA:
        gaps.append("test部署证据schema无效")
    for field, expected in (
        ("projectId", project_id),
        ("iterationId", iteration_id),
        ("requirementId", requirement_id),
        ("testTaskId", test_task_id),
    ):
        if not expected or str(deployment.get(field) or "") != expected:
            gaps.append(f"test部署证据{field}不一致")
    if str(deployment.get("environment") or "").lower() != "test":
        gaps.append("test部署环境不是test")
    if str(deployment.get("status") or "").lower() not in {"成功", "success", "succeeded"}:
        gaps.append("test部署不是成功终态")
    for field in ("executionId", "deployedVersion", "evidenceUrl", "completedAt", "idempotencyKey"):
        if not valid_ref(deployment.get(field)):
            gaps.append(f"test部署证据{field}无效")

    qa = item.get("qaEvidence")
    if not isinstance(qa, dict):
        gaps.append("缺少结构化QA证据")
        return gaps
    if qa.get("schemaVersion") != QA_SCHEMA or qa.get("sourceVerified") is not True:
        gaps.append("QA证据schema或来源校验无效")
    for field, expected in (
        ("projectId", project_id),
        ("iterationId", iteration_id),
        ("requirementId", requirement_id),
        ("testTaskId", test_task_id),
    ):
        if not expected or str(qa.get(field) or "") != expected:
            gaps.append(f"QA证据{field}不一致")
    for field in ("testPlan", "caseRun", "report"):
        value = qa.get(field)
        if not isinstance(value, dict) or not valid_ref(value.get("id")) or not valid_ref(value.get("url")):
            gaps.append(f"QA证据{field}缺ID或URL")
    counts = qa.get("caseCounts")
    if not isinstance(counts, dict):
        gaps.append("QA证据缺结构化用例计数")
    else:
        try:
            normalized_counts = {
                key: as_count(counts, key)
                for key in ("total", "passed", "failed", "blocked", "unexecuted")
            }
            if normalized_counts["total"] != sum(
                normalized_counts[key]
                for key in ("passed", "failed", "blocked", "unexecuted")
            ):
                gaps.append("QA用例计数无法闭合")
            for key, label in (
                ("failed", "失败"),
                ("blocked", "阻塞"),
                ("unexecuted", "未执行"),
            ):
                if normalized_counts[key]:
                    gaps.append(f"QA{label}用例={normalized_counts[key]}")
        except ValueError as error:
            gaps.append(str(error))
    if not valid_ref(qa.get("manifestSha256")) or len(str(qa.get("manifestSha256"))) != 64:
        gaps.append("QA证据清单哈希无效")
    qa_deployment = qa.get("testDeployment")
    if not isinstance(qa_deployment, dict):
        gaps.append("QA证据缺testDeployment")
    else:
        for field in ("executionId", "deployedVersion", "evidenceUrl"):
            if str(qa_deployment.get(field) or "") != str(deployment.get(field) or ""):
                gaps.append(f"QA证据与test部署{field}不一致")

    bugs = item.get("bugs")
    if not isinstance(bugs, list):
        gaps.append("bugs必须是完整关联Bug数组（无Bug时传空数组）")
        return gaps
    normalized_bug_snapshot: list[dict[str, str]] = []
    approvals = qa.get("riskApprovals")
    if not isinstance(approvals, dict):
        approvals = {}
    for bug in bugs:
        if not isinstance(bug, dict) or not valid_ref(bug.get("id")):
            gaps.append("关联Bug缺少有效ID")
            continue
        bug_id = str(bug.get("id"))
        bug_serial = str(bug.get("serialNumber") or bug_id)
        bug_status = str(bug.get("status") or "")
        retest = bug.get("retestEvidence")
        retest_version = ""
        retest_key = ""
        if isinstance(retest, dict):
            retest_version = str(retest.get("deployedVersion") or "")
            retest_key = str(retest.get("idempotencyKey") or "")
        normalized_bug_snapshot.append(
            {
                "id": bug_id,
                "serialNumber": bug_serial,
                "status": bug_status,
                "retestDeployedVersion": retest_version,
                "retestIdempotencyKey": retest_key,
            }
        )
        if bug_status == "暂不修复":
            approval = approvals.get(bug_serial.upper())
            if not isinstance(approval, dict) or not valid_ref(
                approval.get("approver")
            ) or not valid_ref(approval.get("evidence")):
                gaps.append(f"Bug {bug_serial}暂不修复缺批准证据")
            continue
        if bug_status != "已关闭":
            gaps.append(f"Bug {bug_serial}仍为活动状态：{bug_status or '(空)'}")
            continue
        if not isinstance(retest, dict) or retest.get("schemaVersion") != BUG_RETEST_SCHEMA:
            gaps.append(f"Bug {bug_serial}缺逐条复测证据")
            continue
        if str(retest.get("result") or "").lower() != "passed" or str(
            retest.get("environment") or ""
        ).lower() != "test":
            gaps.append(f"Bug {bug_serial}复测未通过或环境非test")
        if str(retest.get("deployedVersion") or "") != str(deployment.get("deployedVersion") or ""):
            gaps.append(f"Bug {bug_serial}复测版本与test部署不一致")
        for field in (
            "caseId",
            "testExecutionId",
            "evidence",
            "verifiedBy",
            "verifiedAt",
            "idempotencyKey",
        ):
            if not valid_ref(retest.get(field)):
                gaps.append(f"Bug {bug_serial}复测证据{field}无效")
    normalized_bug_snapshot.sort(key=lambda value: value["id"])
    expected_bug_snapshot = qa.get("bugSnapshot")
    if expected_bug_snapshot != normalized_bug_snapshot:
        gaps.append("QA证据Bug快照与发布时实时关联Bug不一致")
    snapshot_digest = hashlib.sha256(
        json.dumps(normalized_bug_snapshot, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    if qa.get("bugSnapshotSha256") != snapshot_digest:
        gaps.append("QA证据Bug快照哈希不一致")
    return gaps


def qa_gaps(item: dict[str, Any]) -> list[str]:
    """Require one completed test task for every active development task."""
    gaps: list[str] = []
    if item.get("requirementStatus") != "测试完成":
        gaps.append("需求状态不是测试完成")
    development_tasks = item.get("developmentTasks")
    test_tasks = item.get("testTasks")
    if not isinstance(development_tasks, list) or not development_tasks:
        gaps.append("缺少完整开发任务清单")
        development_tasks = []
    if not isinstance(test_tasks, list):
        gaps.append("缺少完整测试任务清单")
        test_tasks = []

    active_development_ids: set[str] = set()
    for development in development_tasks:
        if not isinstance(development, dict) or not valid_ref(development.get("id")):
            gaps.append("开发任务缺少有效ID")
            continue
        development_id = str(development["id"])
        if str(development.get("status") or "") == "已取消":
            continue
        if development_id in active_development_ids:
            gaps.append(f"开发任务清单存在重复ID：{development_id}")
        active_development_ids.add(development_id)

    mapped_development_ids: set[str] = set()
    allowed_modes = {"formal-plan", "mandatory-test-task", "qa-requested-exception"}
    for test in test_tasks:
        if not isinstance(test, dict) or not valid_ref(test.get("id")):
            gaps.append("测试任务缺少有效ID")
            continue
        test_id = str(test["id"])
        development_id = str(test.get("developmentTaskId") or "")
        if development_id not in active_development_ids:
            gaps.append(f"测试任务{test_id}未映射到本需求有效开发任务")
            continue
        if development_id in mapped_development_ids:
            gaps.append(f"开发任务{development_id}存在多个测试任务")
        mapped_development_ids.add(development_id)
        mode = str(test.get("testMode") or "").strip()
        if mode == "lightweight-verification":
            gaps.append(f"测试任务{test_id}仍使用已停用的轻量验证模式")
        elif mode not in allowed_modes:
            gaps.append(f"测试任务{test_id}测试模式无效：{mode or '(空)'}")
        if str(test.get("status") or "") != "已完成":
            gaps.append(f"测试任务{test_id}不是已完成")
        if not isinstance(test.get("hasRequiredCases"), bool):
            gaps.append(f"测试任务{test_id}未明确是否存在必需用例")
        elif test.get("hasRequiredCases") is True and test.get("requiredCaseStatus") != "passed":
            gaps.append(f"测试任务{test_id}必需用例未通过")

    for development_id in sorted(active_development_ids - mapped_development_ids):
        gaps.append(f"开发任务{development_id}缺少对应测试任务")
    bugs = item.get("bugs")
    if not isinstance(bugs, list):
        gaps.append("未取得完整关联Bug清单")
    else:
        for bug in bugs:
            if not isinstance(bug, dict) or not valid_ref(bug.get("id")):
                gaps.append("关联Bug缺有效ID")
                continue
            status = str(bug.get("status") or "")
            if status != "已关闭":
                gaps.append(
                    f"Bug {bug.get('serialNumber') or bug.get('id')}未关闭：{status or '(空)'}"
                )
    # Legacy auxiliary records are optional. If a caller supplies either one,
    # validate the pair instead of leaving this evidence parser disconnected.
    if item.get("testDeployment") is not None or item.get("qaEvidence") is not None:
        gaps.extend(structured_evidence_gaps(item))
    gaps.extend(handoff_gaps(item, development_tasks, test_tasks))
    return gaps


def handoff_gaps(item: dict[str, Any], development_tasks: list[dict[str, Any]],
                 test_tasks: list[dict[str, Any]]) -> list[str]:
    """Require one current formal handoff bundle for every active development scope."""
    gaps: list[str] = []
    active = {
        str(task.get("id") or ""): task
        for task in development_tasks
        if isinstance(task, dict) and str(task.get("status") or "") != "已取消"
        and valid_ref(task.get("id"))
    }
    mapped_tests: dict[str, list[str]] = {}
    for test in test_tasks:
        if not isinstance(test, dict):
            continue
        development_id = str(test.get("developmentTaskId") or "")
        test_id = str(test.get("id") or "")
        if development_id in active and valid_ref(test_id):
            mapped_tests.setdefault(development_id, []).append(test_id)
    bundles = item.get("releaseHandoffs")
    if not isinstance(bundles, list):
        return ["缺少完整releaseHandoffs数组"]
    seen: set[str] = set()
    for bundle in bundles:
        if not isinstance(bundle, dict):
            gaps.append("发布交棒bundle格式错误")
            continue
        receipt = bundle.get("developmentReceipt")
        development_id = str(receipt.get("taskId") or "") if isinstance(receipt, dict) else ""
        if development_id not in active:
            gaps.append(f"交棒bundle未映射本需求有效开发任务：{development_id or '(空)'}")
            continue
        if development_id in seen:
            gaps.append(f"开发任务{development_id}存在多个发布交棒bundle")
            continue
        seen.add(development_id)
        development = active[development_id]
        missing = [field for field in ("deliveryId", "scopeId", "deliveryVersion")
                   if not valid_ref(development.get(field))]
        if missing:
            gaps.append(f"开发任务{development_id}缺交棒范围字段：{','.join(missing)}")
            continue
        expected_scope = {
            "projectId": str(item.get("projectId") or ""),
            "requirementId": str(item.get("id") or ""),
            "deliveryId": str(development["deliveryId"]),
            "scopeId": str(development["scopeId"]),
        }
        try:
            hg.validate_bundle(
                bundle, "release", expected_scope=expected_scope,
                delivery_version=str(development["deliveryVersion"]),
            )
        except ValueError as error:
            gaps.append(f"开发任务{development_id}交棒门禁失败：{error}")
            continue
        expected_tests = mapped_tests.get(development_id, [])
        qa_receipt = bundle.get("qaReceipt") or {}
        if len(expected_tests) != 1 or qa_receipt.get("taskId") != expected_tests[0]:
            gaps.append(f"开发任务{development_id}的QA回执未精确绑定唯一测试任务")
    for development_id in sorted(set(active) - seen):
        gaps.append(f"开发任务{development_id}缺当前正式发布交棒bundle")
    return gaps


def classify(data: dict[str, Any]) -> dict[str, Any]:
    project_id = str(data.get("projectId") or "").strip()
    iteration_id = str(data.get("iterationId") or "").strip()
    scope_mode = str(data.get("scopeMode") or "iteration").strip()
    if not project_id:
        raise ValueError("projectId不能为空")
    if scope_mode == "iteration" and not iteration_id:
        raise ValueError("迭代模式下iterationId不能为空")
    if scope_mode == "exceptional":
        if not valid_ref(data.get("exceptionalReason")):
            raise ValueError("例外发布必须提供exceptionalReason")
    elif scope_mode != "iteration":
        raise ValueError(f"不支持的scopeMode：{scope_mode}")
    items_raw = data.get("iterationRequirements")
    if not isinstance(items_raw, list):
        raise ValueError("iterationRequirements必须是数组")

    items: dict[str, dict[str, Any]] = {}
    duplicate_ids: list[str] = []
    for raw in items_raw:
        if not isinstance(raw, dict):
            raise ValueError("iterationRequirements每项必须是对象")
        requirement_id = str(raw.get("id") or "").strip()
        if not requirement_id:
            raise ValueError("需求id不能为空")
        if requirement_id in items:
            duplicate_ids.append(requirement_id)
        items[requirement_id] = raw

    selected_raw = data.get("selectedRequirementIds")
    selection_mode = "auto_by_iteration" if selected_raw is None else "explicit"
    if selection_mode == "explicit":
        if not isinstance(selected_raw, list) or not selected_raw:
            raise ValueError("手工局部发布时selectedRequirementIds必须是非空数组")
        selected = [str(value).strip() for value in selected_raw]
        if any(not value for value in selected) or len(selected) != len(set(selected)):
            raise ValueError("选入需求编号不能为空或重复")
        selected_set = set(selected)
    else:
        # 日常入口只给迭代：自动选择已达到需求测试完成状态的项，
        # 仍对这些候选执行完整证据校验；未达到门槛的项仅作为B类留在下一批。
        selected_set = {
            requirement_id for requirement_id, item in items.items()
            if item.get("formallyDeferred") is not True
            and item.get("requirementStatus") == "测试完成"
        }

    groups: dict[str, list[dict[str, Any]]] = {key: [] for key in "ABCD"}
    for duplicate in sorted(set(duplicate_ids)):
        groups["D"].append({"id": duplicate, "reasons": ["迭代快照重复编号"]})

    missing = sorted(selected_set - set(items))
    for requirement_id in missing:
        groups["D"].append({"id": requirement_id, "reasons": ["选入编号不在迭代快照"]})

    for requirement_id, item in items.items():
        reasons: list[str] = []
        formal_direct = item.get("formallyInIteration") is True
        formal_via_delivery = item.get("formallyInIterationViaDelivery") is True
        formal_exceptional = item.get("formallyInExceptionalScope") is True
        formal = formal_exceptional if scope_mode == "exceptional" else (
            formal_direct or formal_via_delivery
        )
        scoped_iteration_id = str(
            item.get("sourceDeliveryIterationId") if formal_via_delivery
            else item.get("iterationId") or ""
        )
        if str(item.get("projectId") or "") != project_id:
            reasons.append("跨项目")
        if scope_mode == "iteration" and scoped_iteration_id != iteration_id:
            reasons.append("跨迭代")
        if not formal:
            reasons.append(
                "缺例外范围到需求的正式关联"
                if scope_mode == "exceptional"
                else "缺迭代交付到需求的正式关联"
            )
        if item.get("relationConflict") is True:
            reasons.append("正式关系冲突")

        selected_for_batch = requirement_id in selected_set
        deferred = item.get("formallyDeferred") is True
        if selected_for_batch and deferred:
            reasons.append("同时选入与延期")
        if reasons:
            groups["D"].append({"id": requirement_id, "reasons": reasons})
            continue

        if not selected_for_batch:
            if deferred:
                reason = str(item.get("deferredReason") or "已正式延期")
            elif selection_mode == "auto_by_iteration":
                reason = "当前未达到测试完成门槛，自动留待下一发布批次"
            else:
                reason = str(item.get("deferredReason") or "手工局部批次未选入")
            groups["B"].append(
                {
                    "id": requirement_id,
                    "reason": reason,
                }
            )
            continue

        gaps = qa_gaps(item)
        if gaps:
            groups["C"].append({"id": requirement_id, "reasons": gaps})
        else:
            groups["A"].append({"id": requirement_id})

    blocking = not groups["A"] or bool(groups["C"] or groups["D"])
    unsafe_identity_reasons = {
        "迭代快照重复编号", "选入编号不在迭代快照", "跨项目", "跨迭代",
        "正式关系冲突", "缺迭代交付到需求的正式关联", "缺例外范围到需求的正式关联",
    }
    unsafe_identity = any(
        reason in unsafe_identity_reasons
        for row in groups["D"]
        for reason in row.get("reasons", [])
    )
    return {
        "ok": not blocking,
        "blocking": blocking,
        "canPersistDraft": not unsafe_identity,
        "releaseReady": not blocking,
        "projectId": project_id,
        "iterationId": iteration_id,
        "scopeMode": scope_mode,
        "selectionMode": selection_mode,
        "selectedRequirementIds": sorted(selected_set),
        "A_releaseScope": groups["A"],
        "B_deferredNonBlocking": groups["B"],
        "C_selectedIncomplete": groups["C"],
        "D_anomalies": groups["D"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="离线判定A/B/C/D发布范围")
    parser.add_argument("--input", default="-", help="JSON文件；- 表示stdin")
    args = parser.parse_args()
    try:
        result = classify(load_json(args.input))
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False, indent=2))
        raise SystemExit(2) from error
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["ok"] else 3)


if __name__ == "__main__":
    main()
